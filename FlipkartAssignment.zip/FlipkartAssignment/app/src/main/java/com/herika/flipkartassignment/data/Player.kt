package com.herika.flipkartassignment.data

data class Player(
    val id: Int,
    val name: String,
    val icon: String
)
